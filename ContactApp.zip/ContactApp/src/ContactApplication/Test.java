package ContactApplication;

import javax.swing.*;
import java.awt.*;

/**
 * Created by Surid on 8/29/2016.
 */
public class Test extends JFrame{
   /* public Test()
    {
        calbtn.setPreferredSize(new Dimension(20,50));
        calbtn.setBounds(20,30,50,30);
        this.add(calbtn);
    }

    public static void main(String args[])
    {
        Test g = new Test();
        g.setLocation(10, 10);
        g.setSize(400, 300);
        g.setTitle("Spell Checker Suggestion");
        g.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        g.setVisible(true);
    }

    mainPanel.setLayout(new GridBagLayout());
        mainPanel.setBackground(Color.ORANGE);
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.VERTICAL;
        c.weightx = 20;
        c.insets = new Insets(5, 5, 5, 5);
        c.gridy = 1;
        mainPanel.add(label1,c);
        c.gridy++;
        mainPanel.add(txtField1,c);
        c.gridy++;
        mainPanel.add(label2,c);
        c.gridy++;
        mainPanel.add(txtField2,c);
        c.gridy++;
        mainPanel.add(label3,c);
        c.gridy++;
        mainPanel.add(txtField3,c);
        c.gridy++;
        mainPanel.add(label4,c);
        c.gridy++;
        mainPanel.add(txtField4,c);
        c.gridy++;
        mainPanel.add(label5,c);
        c.gridy++;
        mainPanel.add(txtField5,c);*/
}
